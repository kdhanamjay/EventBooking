(function ($) {
"use strict";

$('#mainSlider').nivoSlider({
	effect: 'random',
	directionNav: true,
	animSpeed: 500,
	slices: 18,
	pauseTime: 5000000,
	pauseOnHover: false,
	controlNav: false,
    directionNav: false,
});




})(jQuery);	
